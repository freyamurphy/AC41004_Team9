import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uilocationfinder',
  templateUrl: './uilocationfinder.component.html',
  styleUrls: ['./uilocationfinder.component.css']
})
export class UilocationfinderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
