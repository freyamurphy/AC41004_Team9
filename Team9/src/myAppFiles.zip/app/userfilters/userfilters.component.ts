import { Component, OnInit } from '@angular/core';
import { Observable } from  "rxjs/Observable";

import { HttpClient } from  "@angular/common/http";
@Component({
  selector: 'app-userfilters',
  templateUrl: './userfilters.component.html',
  styleUrls: ['./userfilters.component.css']
})
export class UserfiltersComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
    

  }

}
